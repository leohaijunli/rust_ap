#!/usr/bin/env python3
"""Resume QGC evidence after host restarts; verify identity before GUI ownership."""

import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
OUT = SCRIPT_DIR / 'qgc-session'
RECOVERY = SCRIPT_DIR.parent.parent
ROOT = Path('/home/dev/rust_ap')
sys.path.insert(0, str(RECOVERY))
import run_step as recovery

APP = Path('/home/dev/Applications/QGroundControl/5.1.5/QGroundControl-x86_64.AppImage')
EXPECTED = {
    APP: '9a47e4cf269d9e4f897f582f6b19aa7ebf1e9e67c9d68a532a45b541354bc344',
    RECOVERY / 'images/px4-v1.17.0-github.px4': '8f2c42787163b71e00758205ab0bed9df1669fd26d7a9f42d6f995cbabba0d7f',
    RECOVERY / 'images/normal.px4': '7652fa90836be3182becf8f888a052aebc982ecbf67e6ba303dc66719db8fff5',
    RECOVERY / 'images/p0.px4': 'd74b3b80e7c35bf4354ea568c09631f2fad362570caff414516ee0fe48a3c02d',
    RECOVERY / 'run_step.py': '6f18786e1fbc72f96a331fd590231eb313f42367a7b466bd86960cc63661ac28',
}


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_new(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def scan():
    return sorted([
        {'device': port.device, 'vid': port.vid, 'pid': port.pid,
         'product': port.product, 'manufacturer': port.manufacturer,
         'serial': port.serial_number, 'location': port.location,
         'mode': recovery.port_mode(port),
         'read_write_access': os.access(port.device, os.R_OK | os.W_OK)}
        for port in recovery.serial.tools.list_ports.comports() if port.vid is not None
    ], key=lambda port: port['device'])


def main():
    OUT.mkdir(exist_ok=False)
    recovery.ensure(subprocess.run(['pgrep', '-x', 'QGroundControl'], capture_output=True).returncode == 1,
                    'Close existing QGroundControl before the identity check')
    artifacts = []
    for path, expected in EXPECTED.items():
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        recovery.ensure(actual == expected, f'Hash mismatch: {path}')
        artifacts.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': actual})
    report = json.loads((RECOVERY.parent / 'normal.build.json').read_text())
    verified = {}
    for group in ('sources_sha256', 'tools_sha256'):
        verified[group] = len(report[group])
        for name, expected in report[group].items():
            recovery.ensure(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected,
                            f'Build input changed: {name}')
    # The immediately preceding attempt completed this read-only identity
    # check, then stopped at an old empty launch.json. Preserve and reuse it.
    before = json.loads((SCRIPT_DIR / 'before-qgc.json').read_text())
    recovery.ensure(before['outcome'] == 'pass', 'Prior identity check did not pass')
    age = (datetime.now(timezone.utc) - datetime.fromisoformat(before['finished_utc'])).total_seconds()
    recovery.ensure(0 <= age < 600, 'Prior identity check is no longer fresh')
    recovery.ensure(Path('/proc/sys/kernel/random/boot_id').read_text().strip()
                    == '744d775e-da6c-4caa-bad0-b5f0ca30e929', 'Host rebooted after the identity check')
    scans = []
    device = recovery.wait_mode('mavlink', scans)
    recovery.ensure(subprocess.run(['fuser', device], capture_output=True).returncode == 1,
                    'Serial port is already held')
    recovery.ensure(before['snapshot']['platform']['fields']['P1_PLATFORM']['source'] == recovery.NORMAL,
                    'Unexpected identity evidence')
    recovery.ensure(before['snapshot']['fault']['fields']['P1_FAULT']['valid'] == 'false',
                    'A retained fault requires review before continuing')
    argv = [str(APP), '--log-output', '--logging=Vehicle.VehicleSetup,VehicleSetup.FirmwareUpgrade']
    write_new('launch.json', {
        'schema': 1, 'started_utc': utc(), 'argv': argv, 'cwd': str(ROOT),
        'host_boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'identity_evidence': {'result': '../before-qgc.json', 'wire': '../before-qgc-wire.jsonl',
                              'finished_utc': before['finished_utc'], 'age_seconds': age},
        'artifacts': artifacts, 'verified_build_inputs': verified,
        'initial_ports': scan(),
        'environment': {key: os.environ.get(key) for key in (
            'DISPLAY', 'WAYLAND_DISPLAY', 'XDG_SESSION_TYPE', 'XDG_RUNTIME_DIR',
            'QT_QPA_PLATFORM', 'QT_LOGGING_RULES', 'TMPDIR')},
        'official_url': 'https://github.com/PX4/PX4-Autopilot/releases/download/v1.17.0/px4_fmu-v6x_default.px4',
        'monitor_scope': 'Read-only Rust identity snapshot before QGC; passive USB enumeration while QGC runs. No reboot, clear or fault command.',
        'capture_gap': 'Earlier session ended with a host restart; previous engineer Inspector confirmation is retained separately.',
    })
    with (OUT / 'qgc-console.log').open('x', buffering=1) as log, \
            (OUT / 'usb-enumeration.jsonl').open('x', buffering=1) as usb:
        process = subprocess.Popen(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        write_new('process.json', {'qgc_pid': process.pid, 'monitor_pid': os.getpid(), 'started_utc': utc()})
        print(f'QGC PID={process.pid}; evidence={OUT}', flush=True)
        previous = None
        while True:
            ports = scan()
            if ports != previous:
                usb.write(json.dumps({'at_utc': utc(), 'host_ns': time.monotonic_ns(), 'ports': ports}) + '\n')
                usb.flush()
                os.fsync(usb.fileno())
                previous = ports
            result = process.poll()
            if result is not None:
                break
            time.sleep(0.05)
        log.flush()
        os.fsync(log.fileno())
        write_new('exit.json', {'finished_utc': utc(), 'returncode': result})
        print(f'QGC exited: {result}', flush=True)
        return result


if __name__ == '__main__':
    sys.exit(main())
