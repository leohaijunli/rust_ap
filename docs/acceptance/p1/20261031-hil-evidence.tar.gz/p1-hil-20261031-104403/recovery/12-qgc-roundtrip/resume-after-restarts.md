# 两次主机重启后的续接

本轮QGC留档没有完成时，harness两次报告server重启；实际主机boot ID也先后改变。原始记录与工程师“四条均可见”的Inspector确认保留，不把中断空档当连续采集。

- 首轮X11初始化失败：`DISPLAY=:0`的文件socket缺失，抽象socket拒绝连接；QtCore调用abort。xcb-cursor实际存在，详见`display-diagnosis.json`及`coredump-info.log`。
- `wayland-retry/`因QGC不支持`-platform`参数退出；`wayland-environment/`通过子进程环境启动原生Wayland。工程师确认四条消息可见，但Inspector截图尚未完成；`startup-window.png`实际只是桌面背景。
- 第一次续接boot ID=`530211da-3294-4d75-8601-6ea135297fc6`，QGC/monitor均已退出，飞控USB未枚举；第二次续接boot ID=`744d775e-da6c-4caa-bad0-b5f0ca30e929`。工程师随后回答“已接好，固件未变”，Rust CDC已重新出现。
- 第二次续接发现旧`capture_qgc.py`尾部421个NUL、`startup-diagnosis.md`尾部658个NUL，以及全为NUL的`capture_window.py`（2181 B）。文件按发现状态保留，不能作为有效脚本/完整报告。旧脚本的前5555 B与`wayland-environment/capture_qgc.py`完整快照相同；损坏发生机制未确认。
- `--after-host-restart`执行在Python语法加载阶段失败，没有打开飞控或启动QGC。新`after-host-restart/launch.py`先验证18个源码及17个工具hash、精确镜像和当前板上source/故障状态，再启动官方QGC。主机重启后X11 socket已重建，本次使用官方默认环境。
- 仓库非ignored文本扫描未发现NUL；已完成的板测不重复，当前身份核验用于绑定续接后的QGC证据。

原始启动文件受损部分不可凭记忆当作原始证据重造。本说明是后续诊断记录，保留失败、重试和测量空档。

20:15 UTC补充：新只读身份核验通过，source=`a946a529360eac83`、fault_injection=false、valid=false，平台/备份域正常；原始wire与结果在`after-host-restart/before-qgc*`。随后启动在既有0 B的`launch.json`处按不覆盖策略停止。该目录还发现0 B的process/console/USB文件，均保留。下一次使用全新`qgc-session/`输出，复用同一boot下刚取得的身份结果，不重做已完成板测。
