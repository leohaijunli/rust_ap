#!/usr/bin/env python3
"""Focus the existing QGC window and save an unedited, bounded screenshot."""

import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

out = Path(__file__).resolve().parent / 'qgc-session'
if len(sys.argv) != 2 or not re.fullmatch(r'[a-z0-9-]+', sys.argv[1]):
    raise SystemExit('Choose a fresh evidence label')
label = sys.argv[1]
image = out / (label + '.png')
record = out / (label + '.json')
if image.exists() or record.exists():
    raise SystemExit('Evidence already exists')
clients = json.loads(subprocess.check_output(['hyprctl', '-j', 'clients']))
windows = [window for window in clients if 'qgroundcontrol' in window.get('class', '').lower()]
if len(windows) != 1 or not windows[0]['mapped']:
    raise SystemExit('Expected one mapped QGC window')
window = windows[0]
focus = ['hyprctl', 'dispatch', 'hl.dsp.focus({ window = "address:' + window['address'] + '" })']
subprocess.run(focus, check=True, capture_output=True, text=True)
time.sleep(0.35)  # Allow the workspace animation to render before the capture.
active = json.loads(subprocess.check_output(['hyprctl', '-j', 'activewindow']))
if active.get('address') != window['address']:
    raise SystemExit('QGC did not retain focus; no screenshot captured')
x, y = active['at']
width, height = active['size']
capture = ['grim', '-g', f'{x},{y} {width}x{height}', str(image)]
subprocess.run(capture, check=True)
with image.open('rb') as stream:
    os.fsync(stream.fileno())
data = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'window': active,
        'focus_command': focus, 'capture_command': capture,
        'image_sha256': hashlib.sha256(image.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with record.open('x') as stream:
    json.dump(data, stream, indent=2)
    stream.write('\n')
    stream.flush()
    os.fsync(stream.fileno())
print(json.dumps({'image': str(image), 'sha256': data['image_sha256']}, indent=2))
