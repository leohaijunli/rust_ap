# Pixhawk 6X Rust 飞控 TODO

更新：2026-10-31。**P0 软件收口；P1 进行中；M1 待验收。**
实施要求：[plan.md](plan.md) · 硬件：[台账](docs/fmuv6x-hardware.md) · 证据：[P0](docs/acceptance/p0/README.md) / [P1](docs/acceptance/p1/README.md)

## 执行规则

- `[x]` 必须有证据；`[agent]` 为软件工作，`[HIL]` 由工程师操作唯一的板子。
- 阶段验收通过后才放行依赖阶段；原始结果、版本/hash、阈值及执行者写入 `docs/acceptance/`。
- 保留原 PX4 bootloader、`0x08020000` 应用入口及 **QGC 刷回官方 PX4** 的能力。
- 每次更新展示当前阶段的完成/进行/待验项，同步本文件与 `plan.md`；TODO 保持简短。

## 已确认范围

- [x] **D-A3 / D-RUST / D-EMBASSY**：当前工程 + 纯 Rust/Embassy 设备层 + 按需复用固定 Cybflight 算法。
- [x] **D-M1 / D-QGC-M1 / D-PARAM**：IMU、AHRS、DroneCAN、ULog、USB/TELEM1、上游 QGC 消息及标准参数读设。
- [x] **D-IMU / D-ESC / D-GNSS**：仅 SPI2 ICM-42688-P；4 个 Vimdrones Nano、Quad X；H-RTK DroneCAN SKU12059。
- [x] **D-PUBLIC / D-HOLSATUS / D-DEFER**：允许 GPL 来源复用并记录许可；跳过 Holsatus 构建修复；远期细节等 M1 硬件结果。
- [x] **P0-01～10 / H-01**：基线、来源、硬件资料、A3/M1 架构及预算提案已归档；数值尚非硬件验收值。

## P1 — 保持 QGC 恢复能力的 bring-up

依赖：P0。完整状态与历史见 [P1 索引](docs/acceptance/p1/README.md)。

- [x] **P1-03** `[agent]` 构建/打包/布局、版本报告、监看工具与离线回归完成。
- [x] **P1-02** `[HIL]` 新普通版 source、完整协议、真实寄存器及 schema-2 备份域保持通过，见[板上记录](docs/acceptance/p1/20261031-hil.md)。
- [x] **备份域软件修复** `[agent]` RTC/LSE 保持、schema-2 诊断与三版各 132 场景回放通过；12 Rust / 64 Python 通过，见[证据](docs/acceptance/p1/20261031-backup-domain.md)。
- [x] **P1-04 已测** `[HIL]` 两组≥65 s时基/1 kHz/CPU/栈、文本/MAVLink重启、panic/HardFault记录保持与清除通过，见[证据](docs/acceptance/p1/20261031-hil.md)。
- [ ] **P1-01 / H-05** `[HIL]` PX4 v1.17.0启动、P0/新普通回装已核验；补完整QGC往返日志/Inspector。原参数/校准/FRAM无备份。
- [ ] **P1-04 收口** `[HIL]` 完成QGC往返、最终普通确认和工程师回填；FMU灯目视项因本板无可观察灯不适用，ETH观察另记。
- [ ] **P1 收尾**：完整验收通过后 commit / push（用户已要求）。

下一步：QGC Inspector → 独立USB入口刷官方PX4 → 回装P0/验收普通包；归档后关闭P1并commit/push。

## 待补硬件资料

| 编号 | 所需输入 | 阻塞阶段 |
| --- | --- | --- |
| H-02 | 4 个 ESC 固件/参数、节点/索引与电机映射 | P4b-a；旋向/超时归 P4b-b |
| H-03 | CAN 适配器、端口/拓扑、供电、接线、终端 | CAN 上板 |
| H-04 | SD 卡与 ULog 记录/sync/dropout/掉电测试采用值 | PL-a |
| H-06 | 台架限幅/时限、取消与故障停转判据 | P5a |
| H-07 | RC 协议/UART、电源监测、飞行预检与故障策略 | P5b |
| H-08 | GNSS 坐标/杆臂、精度/降级指标与 HIL 条件 | P6c/P6d |
| H-09 | 质量/惯量、动力模型、辨识与求解预算 | P6f |
| H-10 | H-RTK SKU/固件、节点、消息率/接线；后补 RTCM 源 | P4b-g / P4b-r |

## M1 前置阶段

下列均待完成；每行的软件与 HIL 必需项全部通过后才勾选。

- [ ] **P3a / P3A-01～04**：FRAM 只读识别/备份、唯一参数表、原子持久化及掉电/升级验收。依赖 P1。
- [ ] **P4b-a / CAN-A01～04**：v0 栈/DSDL 对拍、FDCAN/节点服务、ESC 映射/Status、零命令与 DISARMED 验收。依赖 P1、P3a、H-02/03。
  - **CAN-DNA**：仅设备必须动态分配时实现并验收；静态 ID 可用则记录不适用。
- [ ] **PL-a / LOG-A01～05**：纯 Rust ULog、有界缓冲、SDMMC2/FAT；30 分钟负载、20 次随机断电及存储故障验收。依赖 P3a、P4b-a、H-04。
- [ ] **P4b-g / GNSS-01～与断线联合负载。依赖 P4b-a、PL-a、H-10。
- [ ] **P2 / MAV-01～03**：USB/TELEM1 双链路、标准消息/命令、QGC 连接与重连。依赖 P1、P3a。
- [ ] **P3 协议 / PARAM-01～02**：PARAM_* 标准读设/实际值回显，QGC 受控读写 100 次及掉电恢复。依赖 P3a、P2。
- [ ] **P4 / SENS-01～04**：唯一 ICM-42688-P 的 ID/方向、DRDY/FIFO/DMA、SI 单位/校准与采样验收。依赖 P1、P3a、PL-a。
- [ ] **P6a / EST-01～02**：Mahony gyro/accel AHRS、回放、姿态日志/遥测与 QGC 方向验收；yaw 为相对航向。依赖 P4、P2、PL-a。
- [ ] **P7 / TEL-01～02**：随真实数据源补 IMU/ESC/GNSS 等遥测、流速控制及双链路验收；融合位置仅在有效时发布。
- [ ] **M1-01～02**：统一配置/合成回放；IMU→AHRS、ESC/GNSS、ULog、USB/TELEM1、QGC 消息/参数连续联合运行 30 分钟。依赖以上阶段及已有数据源遥测；始终零命令/DISARMED。

## M1 后续

- [ ] **PL-b / LOG-B01～02**：关闭日志的列表/下载/取消/删除及字节校验。依赖 M1、PL-a、P2。
- [ ] **P4b-r / RTK-01～02**：GPS_RTCM_DATA 重组→RTCMStream、限速/源仲裁及 RTK 验收。依赖 M1、P2、P4b-g、H-10。
- [ ] **P5a / OUT-A01～02**：单一输出仲裁、短时授权/撤销、看门狗/保存门控，先零输出验收。依赖 M1、P4b-a、PL-a、H-06。
- [ ] **P4b-b / CAN-B01～03**：拆桨限流核对电机、停止/超时/bus-off/复位与联合负载；恢复不自动解锁。依赖 P5a、P4b-a、PL-a。
- [ ] **P5b / OUT-B01～02**：直连 RC、仲裁/预检/解锁状态机与台架验收。依赖 M1、P6a、P4b-b、P2/P3、H-07。
- [ ] **P6 / CTRL-01～03**：速率/姿态控制、分配、时序/资源及拆桨台架/系留验收。依赖 P6a、P5b、PL-b。

## Backlog

细节与预算待 M1 硬件结果，按依赖顺序推进：

- [ ] **P6b / MODE-01**：模式/转移/控制器槽位。依赖 P6。
- [ ] **P6c / NAV-01**：GNSS 融合与位置/速度/高度控制。依赖 P6b、P4b-g、H-08；RTK 指标另依赖 P4b-r。
- [ ] **P6d / PATH-01**：路径/轨迹跟踪与任务入口。依赖 P6c。
- [ ] **P6e / SHADOW-01**：影子控制器、健康基线与快速回退。依赖 P6d。
- [ ] **P6f / INDI-01、NMPC-01、TRAJ-01**：模型/辨识、控制器与轨迹；有界求解及故障回退。依赖 P6e、H-09。
- [ ] **P6g / MISSION-01～02**：任务协议、QGC/仿真及日志回归。依赖 P6f、P2/P3、PL-b。
- [ ] **BACK-01～03**：参数元数据、按需外设/冗余、发布自动化与更完整 CI。
