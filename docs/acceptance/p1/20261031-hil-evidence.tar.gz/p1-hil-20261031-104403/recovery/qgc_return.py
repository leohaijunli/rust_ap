#!/usr/bin/env python3
"""Explicit post-QGC steps, preserving readback, reboot and upload evidence."""

import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import serial
from pymavlink.dialects.v20 import common as mav2

import run_step as recovery
from px4_uploader import Firmware

BASE = Path(__file__).resolve().parent
ROOT = Path('/home/dev/rust_ap')
HASHES = {
    'px4-v1.17.0-qgc-roundtrip.px4': '3206a5f445d85be730a4f6158d8fdd414b9cfab27fa84bbc05c6a6752deac284',
    'px4-v1.17.0-github.px4': '8f2c42787163b71e00758205ab0bed9df1669fd26d7a9f42d6f995cbabba0d7f',
    'p0.px4': 'd74b3b80e7c35bf4354ea568c09631f2fad362570caff414516ee0fe48a3c02d',
    'normal.px4': '7652fa90836be3182becf8f888a052aebc982ecbf67e6ba303dc66719db8fff5',
}
STEPS = ('13-px4-running', '14-px4-to-p0', '15-p0-to-normal')


def utc():
    return datetime.now(timezone.utc).isoformat()


def json_value(value):
    if isinstance(value, (bytes, bytearray)):
        return list(value)
    raise TypeError(type(value).__name__)


def save(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, default=json_value, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def close_session(session):
    if session is not None:
        session.raw.flush()
        os.fsync(session.raw.fileno())
        session.close()


def open_session(mode, result, path):
    device = recovery.wait_mode(mode, result['scans'])
    recovery.ensure(subprocess.run(['fuser', device], capture_output=True).returncode == 1,
                    'Serial port is held by another process')
    return recovery.Session(device, path)


def wait_heartbeat(session, autopilot, seconds=6):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        session.capture.poll()
        heartbeats = [m for m in session.messages if m['message']['mavpackettype'] == 'HEARTBEAT']
        if heartbeats:
            heartbeat = heartbeats[-1]
            recovery.ensure((heartbeat['system'], heartbeat['component']) == (1, 1), 'Unexpected vehicle identity')
            recovery.ensure(heartbeat['message']['autopilot'] == autopilot, 'Unexpected autopilot')
            recovery.ensure(not heartbeat['message']['base_mode'] & 128, 'Vehicle heartbeat is armed')
            return heartbeat
    raise RuntimeError('No expected heartbeat')


def query_bootloader(device, path):
    """Only GET_SYNC, GET_DEVICE and GET_CRC; no erase/write/reboot command."""
    with serial.Serial(device, 115200, timeout=0.05, write_timeout=1, exclusive=True) as port, \
            path.open('x', buffering=1) as raw:
        def log(direction, data):
            raw.write(json.dumps({'at_utc': utc(), 'host_ns': time.monotonic_ns(),
                                  'direction': direction, 'hex': data.hex()}) + '\n')
            raw.flush()
            os.fsync(raw.fileno())

        def request(command, count):
            packet = command + b'\x20'
            log('tx', packet)
            recovery.ensure(port.write(packet) == len(packet), 'Short bootloader write')
            data = b''
            deadline = time.monotonic() + 8
            while len(data) < count + 2 and time.monotonic() < deadline:
                chunk = port.read(count + 2 - len(data))
                if chunk:
                    log('rx', chunk)
                    data += chunk
            recovery.ensure(len(data) == count + 2 and data[-2:] == b'\x12\x10',
                            f'Unexpected bootloader reply for {packet.hex()}: {data.hex()}')
            return int.from_bytes(data[:-2], 'little')

        request(b'\x21', 0)
        info = {name: request(bytes([0x22, index]), 4) for index, name in (
            (1, 'protocol'), (2, 'board_id'), (3, 'board_revision'), (4, 'flash_size'))}
        recovery.ensure(info['protocol'] >= 3 and info['board_id'] == 53
                        and info['flash_size'] == 1966080, 'Unexpected bootloader identity')
        info['application_crc'] = f'{request(bytes([0x29]), 4):08X}'
        return info


def upload(out, result, image_name):
    image = BASE / 'images' / image_name
    arguments = [sys.executable, '-u', str(BASE / 'px4_uploader.py'),
                 '--port', '/dev/serial/by-id/*PX4_BL*', '--debug', '--noninteractive-json', str(image)]
    result['upload'] = {'command': arguments, 'image_sha256': HASHES[image_name]}
    with (out / 'upload.log').open('x') as log:
        completed = subprocess.run(arguments, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=90)
        log.flush()
        os.fsync(log.fileno())
    result['upload']['returncode'] = completed.returncode
    recovery.ensure(completed.returncode == 0, 'Uploader failed')
    text = (out / 'upload.log').read_text()
    expected = re.findall(r'Expected CRC: 0x([0-9A-Fa-f]+)', text)
    reported = re.findall(r'Reported CRC: 0x([0-9A-Fa-f]+)', text)
    result['upload']['crc'] = {'expected': expected, 'reported': reported}
    expected_value = f'{Firmware(image).crc(1966080):08X}'
    recovery.ensure(expected == reported == [expected_value], 'Missing/mismatched upload CRC')


def protocol(out, result, arguments):
    command = [sys.executable, str(ROOT / 'tools/check_mavlink.py'), *arguments]
    with (out / 'protocol.log').open('x') as log:
        completed = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=45)
        log.flush()
        os.fsync(log.fileno())
    result['protocol'] = {'command': command, 'returncode': completed.returncode}
    recovery.ensure(completed.returncode == 0, 'Protocol regression failed')


def main():
    recovery.ensure(len(sys.argv) == 2 and sys.argv[1] in STEPS, 'Select one explicit post-QGC step')
    name = sys.argv[1]
    recovery.ensure(subprocess.run(['pgrep', '-x', 'QGroundControl'], capture_output=True).returncode == 1,
                    'QGroundControl must be closed')
    for filename, expected in HASHES.items():
        recovery.ensure(hashlib.sha256((BASE / 'images' / filename).read_bytes()).hexdigest() == expected,
                        f'Image hash mismatch: {filename}')
    recovery.ensure(hashlib.sha256((BASE / 'px4_uploader.py').read_bytes()).hexdigest()
                    == 'f05929e1035e693005677e088e4e7085503b2e8ab3d7c8785f7bd84cd48880f8', 'Uploader changed')
    if name != STEPS[0]:
        previous = STEPS[STEPS.index(name) - 1]
        recovery.ensure(json.loads((BASE / previous / 'result.json').read_text())['outcome'] == 'pass',
                        'Previous step did not pass')
    out = BASE / name
    out.mkdir(exist_ok=False)
    result = {'schema': 1, 'step': name, 'started_utc': utc(), 'outcome': 'incomplete', 'scans': [],
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    session = None
    try:
        if name == '13-px4-running':
            session = open_session('px4', result, out / 'wire.jsonl')
            result['heartbeat'] = wait_heartbeat(session, mav2.MAV_AUTOPILOT_PX4)
            message = mav2.MAVLink_command_long_message(
                1, 1, mav2.MAV_CMD_REQUEST_MESSAGE, 0, 148, 0, 0, 0, 0, 0, 0)
            session.capture.write(message.pack(session.capture.encoder))
            deadline = time.monotonic() + 15
            while time.monotonic() < deadline:
                session.capture.poll()
            versions = [m for m in session.messages if m['message']['mavpackettype'] == 'AUTOPILOT_VERSION']
            heartbeats = [m for m in session.messages if m['message']['mavpackettype'] == 'HEARTBEAT']
            result.update({'messages': session.messages, 'decoded_frames': session.capture.valid_frames,
                           'decode_errors': session.capture.bad_frames, 'heartbeats': len(heartbeats)})
            recovery.ensure(versions and len(heartbeats) >= 5, 'PX4 version/heartbeat evidence incomplete')
            version = versions[-1]
            value = version['message']['flight_sw_version']
            result['version'] = '.'.join(str((value >> shift) & 255) for shift in (24, 16, 8))
            result['version_message'] = version
            recovery.ensure((version['system'], version['component']) == (1, 1)
                            and result['version'] == '1.17.0'
                            and version['message']['board_version'] == 53, 'Unexpected PX4 version/board')
            recovery.ensure(all(not h['message']['base_mode'] & 128 for h in heartbeats), 'Armed heartbeat observed')
            recovery.ensure(session.capture.bad_frames == 0, 'MAVLink decode errors')
        else:
            is_px4 = name == '14-px4-to-p0'
            session = open_session('px4' if is_px4 else 'mavlink', result, out / 'before-wire.jsonl')
            result['heartbeat'] = wait_heartbeat(session, mav2.MAV_AUTOPILOT_PX4 if is_px4 else mav2.MAV_AUTOPILOT_GENERIC)
            result['trigger'] = session.trigger('mavlink-reboot')
            close_session(session)
            session = None
            device = recovery.wait_mode('bootloader', result['scans'])
            if is_px4:
                result['installed_px4'] = query_bootloader(device, out / 'bootloader-crc-wire.jsonl')
                expected = {filename: f'{Firmware(BASE / "images" / filename).crc(1966080):08X}'
                            for filename in ('px4-v1.17.0-qgc-roundtrip.px4', 'px4-v1.17.0-github.px4')}
                result['installed_px4']['candidate_crcs'] = expected
                result['installed_px4']['matching_packages'] = [filename for filename, crc in expected.items()
                    if crc == result['installed_px4']['application_crc']]
                recovery.ensure(result['installed_px4']['matching_packages'] == ['px4-v1.17.0-qgc-roundtrip.px4'],
                                'Installed PX4 CRC does not match the freshly saved QGC package')
            upload(out, result, 'p0.px4' if is_px4 else 'normal.px4')
            recovery.wait_mode('mavlink', result['scans'])
            if is_px4:
                protocol(out, result, ['--expected-version', '0.1.0'])
            else:
                session = open_session('mavlink', result, out / 'after-wire.jsonl')
                result['after'] = session.snapshot(recovery.NORMAL)
                recovery.ensure(result['after']['fault']['fields']['P1_FAULT']['valid'] == 'false', 'Retained fault at finish')
                session.capture.write(b'!status\n')
                result['status_lines'] = []
                deadline = time.monotonic() + 1.5
                while time.monotonic() < deadline:
                    result['status_lines'].extend(session.capture.poll())
                close_session(session)
                session = None
                protocol(out, result, ['--source-id', recovery.NORMAL])
        result['outcome'] = 'pass'
    except BaseException as error:
        result['outcome'] = 'failed'
        result['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        close_session(session)
        result['finished_utc'] = utc()
        save(out / 'result.json', result)
        print(json.dumps({'step': name, 'outcome': result['outcome'], 'error': result.get('error'),
                          'version': result.get('version'), 'installed_px4': result.get('installed_px4'),
                          'upload_crc': result.get('upload', {}).get('crc'), 'evidence': str(out)}, indent=2), flush=True)


if __name__ == '__main__':
    main()
