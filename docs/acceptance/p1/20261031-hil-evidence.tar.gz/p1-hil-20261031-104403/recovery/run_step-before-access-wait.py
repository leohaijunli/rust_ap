#!/usr/bin/env python3
"""One explicitly selected, logged recovery step for this engineer session."""

import hashlib
import json
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import serial
import serial.tools.list_ports
from pymavlink.dialects.v20 import common as mav2

ROOT = Path('/home/dev/rust_ap')
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools'))
from backup_domain import decode_backup
from check_mavlink import port_mode as rust_port_mode
from p1_capture import Capture, PREFIXES

PREFIXES.update({'Rust', 'USB33RDY=true', 'USB33RDY=false', 'PHY', 'LAN8742', 'LED', 'FAULT_CLEAR'})
NORMAL = 'a946a529360eac83'
INJECTION = '0de073823b066c6e'
IMAGES = {
    NORMAL: ('normal.px4', '7652fa90836be3182becf8f888a052aebc982ecbf67e6ba303dc66719db8fff5'),
    INJECTION: ('injection.px4', '013adbb372538c7025033402db72a87453725ef586878ae537187e7cad78a157'),
}
# previous step, source before, command, source after, expected new fault kind
STEPS = {
    '01-text-reboot-retry': (None, NORMAL, '!bootloader', NORMAL, None),
    '02-mavlink-reboot': ('01-text-reboot-retry', NORMAL, 'mavlink-reboot', NORMAL, None),
    '03-install-panic': ('02-mavlink-followup', NORMAL, '!bootloader', INJECTION, None),
    '04-panic': ('03-install-panic', INJECTION, '!panic', NORMAL, 1),
    '05-panic-retention': ('04-panic', NORMAL, '!bootloader', NORMAL, None),
    '06-clear-panic': ('05-panic-retention', NORMAL, '!fault-clear', NORMAL, None),
    '07-install-hardfault': ('06-clear-panic', NORMAL, '!bootloader', INJECTION, None),
    '08-hardfault': ('07-install-hardfault', INJECTION, '!hardfault', NORMAL, 2),
    '09-hardfault-retention': ('08-hardfault', NORMAL, 'mavlink-reboot', NORMAL, None),
    '10-clear-hardfault': ('09-hardfault-retention', NORMAL, '!fault-clear', NORMAL, None),
}


def utc():
    return datetime.now(timezone.utc).isoformat()


def port_mode(port):
    # This board's official application and bootloader share VID:PID.
    if (port.vid, port.pid) == (0x3185, 0x0035):
        return 'bootloader' if 'PX4 BL' in (port.product or '') else 'px4'
    return rust_port_mode(port)


def ensure(condition, message):
    if not condition:
        raise RuntimeError(message)


def wait_mode(mode, record, seconds=15):
    deadline = time.monotonic() + seconds
    previous = None
    while True:
        ports = list(serial.tools.list_ports.comports())
        observed = [{'device': p.device, 'vid': p.vid, 'pid': p.pid,
                     'serial': p.serial_number, 'product': p.product, 'mode': port_mode(p)}
                    for p in ports if p.vid is not None]
        if observed != previous:
            record.append({'at_utc': utc(), 'host_ns': time.monotonic_ns(), 'ports': observed})
            previous = observed
        relevant = [p for p in ports if port_mode(p) in ('mavlink', 'dump', 'bootloader', 'px4')]
        ensure(len(relevant) <= 1, 'More than one relevant USB device')
        matches = [p for p in relevant if port_mode(p) == mode]
        if matches:
            return matches[0].device
        ensure(time.monotonic() < deadline, f'Timed out waiting for {mode}')
        time.sleep(0.05)


class Session:
    def __init__(self, device, path):
        self.raw = path.open('x', buffering=1)
        try:
            self.port = serial.Serial(device, 115200, timeout=0.005,
                                      write_timeout=0.5, exclusive=True)
        except BaseException:
            self.raw.close()
            raise
        self.capture = Capture(self.port, self.raw, 0)
        self.messages = []
        self.settled = False
        self.capture.decoder.set_callback(self.received)

    def received(self, message):
        if message.get_type() in ('HEARTBEAT', 'AUTOPILOT_VERSION', 'COMMAND_ACK'):
            self.messages.append({'host_ns': time.monotonic_ns(),
                                  'system': message.get_srcSystem(),
                                  'component': message.get_srcComponent(),
                                  'message': message.to_dict()})

    def close(self):
        self.port.close()
        self.raw.close()

    def snapshot(self, expected):
        # Allow a new CDC session to settle before the first request. Record
        # all initial traffic; a heartbeat alone did not prove request readiness.
        if not self.settled:
            until = time.monotonic() + 2
            while time.monotonic() < until:
                self.capture.poll()
            self.settled = True
        deadline = time.monotonic() + 6
        while not any(m['message']['mavpackettype'] == 'HEARTBEAT' for m in self.messages):
            ensure(time.monotonic() < deadline, 'No heartbeat')
            self.capture.poll()
        heartbeat = next(m for m in reversed(self.messages)
                         if m['message']['mavpackettype'] == 'HEARTBEAT')
        ensure((heartbeat['system'], heartbeat['component']) == (1, 1), 'Unexpected MAVLink identity')
        ensure(not heartbeat['message']['base_mode'] & mav2.MAV_MODE_FLAG_SAFETY_ARMED, 'Armed heartbeat')
        platform = self.capture.request('!platform')
        fault = self.capture.request('!fault')
        metrics = self.capture.request('!metrics')
        header = platform['fields']['P1_PLATFORM']
        ensure(header['schema'] == '2' and header['version'] == '0.2.0', 'Unexpected platform schema/version')
        ensure(header['source'] == expected, f'Unexpected source {header["source"]}')
        ensure(header['fault_injection'] == str(expected == INJECTION).lower(), 'Unexpected injection feature')
        ensure(platform['fields']['CLOCK']['registers_ok'] == 'true', 'Clock verification failed')
        ensure(decode_backup(platform['fields']['BACKUP'])['preserved'], 'Backup-domain verification failed')
        return {'platform': platform, 'fault': fault, 'metrics': metrics, 'heartbeat': heartbeat,
                'messages': list(self.messages), 'captured_utc': utc()}

    def trigger(self, command):
        start = len(self.messages)
        if command == 'mavlink-reboot':
            message = mav2.MAVLink_command_long_message(
                1, 1, mav2.MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN, 0, 3, 0, 0, 0, 0, 0, 0)
            data = message.pack(self.capture.encoder)
        else:
            data = command.encode() + b'\n'
        result = {'command': command, 'sent_utc': utc(), 'host_ns': time.monotonic_ns(),
                  'tx_hex': data.hex(), 'console': [], 'ack_received': False}
        self.capture.write(data)
        deadline = time.monotonic() + 1.5
        while time.monotonic() < deadline:
            try:
                result['console'].extend(self.capture.poll())
            except serial.SerialException as error:
                result['disconnect_error'] = str(error)
                break
        result['messages'] = self.messages[start:]
        if command == 'mavlink-reboot':
            result['ack_received'] = any(
                m['system'] == 1 and m['component'] == 1
                and m['message']['mavpackettype'] == 'COMMAND_ACK'
                and m['message']['command'] == mav2.MAV_CMD_PREFLIGHT_REBOOT_SHUTDOWN
                and m['message']['result'] == mav2.MAV_RESULT_ACCEPTED
                for m in result['messages'])
        else:
            expected = 'OK bootloader' if command == '!bootloader' else 'OK fault-injection'
            result['ack_received'] = expected in result['console']
        return result


def main():
    ensure(len(sys.argv) == 2 and sys.argv[1] in STEPS, 'Select one explicit step: ' + ', '.join(STEPS))
    name = sys.argv[1]
    previous, before_source, command, after_source, new_fault = STEPS[name]
    if previous:
        ensure(json.loads((BASE / previous / 'result.json').read_text())['outcome'] == 'pass',
               f'Previous step {previous} did not pass')
    ensure(subprocess.run(['pgrep', '-x', 'QGroundControl'], capture_output=True).returncode == 1,
           'QGroundControl is running; close it before serial operations')
    filename, checksum = IMAGES[after_source]
    image = BASE / 'images' / filename
    ensure(hashlib.sha256(image.read_bytes()).hexdigest() == checksum, 'Firmware hash mismatch')
    uploader = BASE / 'px4_uploader.py'
    ensure(hashlib.sha256(uploader.read_bytes()).hexdigest()
           == 'f05929e1035e693005677e088e4e7085503b2e8ab3d7c8785f7bd84cd48880f8', 'Uploader hash mismatch')
    out = BASE / name
    out.mkdir(exist_ok=False)
    result = {'schema': 1, 'step': name, 'started_utc': utc(), 'outcome': 'incomplete',
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'image': str(image), 'image_sha256': checksum, 'scans': []}
    session = None
    try:
        device = wait_mode('mavlink', result['scans'])
        ensure(subprocess.run(['fuser', device], capture_output=True).returncode == 1,
               'Serial device is held by another process')
        session = Session(device, out / 'before-wire.jsonl')
        result['before'] = session.snapshot(before_source)
        if command == '!fault-clear':
            result['clear'] = session.capture.request(command)
            ensure(result['clear']['fields']['FAULT_CLEAR']['ok'] == 'true', 'Fault clear failed')
            result['after'] = session.snapshot(after_source)
            ensure(result['after']['fault']['fields']['P1_FAULT']['valid'] == 'false', 'Fault still valid')
        else:
            if new_fault:
                # Preserve the pre-clear report before starting this one controlled injection.
                result['clear'] = session.capture.request('!fault-clear')
                ensure(result['clear']['fields']['FAULT_CLEAR']['ok'] == 'true', 'Fault clear failed')
                result['cleared_fault'] = session.capture.request('!fault')
                ensure(result['cleared_fault']['fields']['P1_FAULT']['valid'] == 'false', 'Fault still valid')
            result['trigger'] = session.trigger(command)
            session.close()
            session = None
            wait_mode('bootloader', result['scans'])
            arguments = [sys.executable, '-u', str(uploader), '--port', '/dev/serial/by-id/*PX4_BL*',
                         '--debug', '--noninteractive-json', str(image)]
            result['uploader_command'] = arguments
            with (out / 'upload.log').open('x') as log:
                completed = subprocess.run(arguments, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=90)
            result['uploader_returncode'] = completed.returncode
            ensure(completed.returncode == 0, 'Uploader failed; see upload.log')
            text = (out / 'upload.log').read_text()
            expected_crc = re.findall(r'Expected CRC: 0x([0-9A-Fa-f]+)', text)
            reported_crc = re.findall(r'Reported CRC: 0x([0-9A-Fa-f]+)', text)
            result['crc'] = {'expected': expected_crc, 'reported': reported_crc}
            ensure(len(expected_crc) == len(reported_crc) == 1 and expected_crc == reported_crc,
                   'Missing or mismatched CRC evidence')
            device = wait_mode('mavlink', result['scans'])
            session = Session(device, out / 'after-wire.jsonl')
            result['after'] = session.snapshot(after_source)
            ensure(result['trigger']['ack_received'], 'Reboot/injection ACK not observed')
            actual = result['after']['fault']['fields']
            if new_fault:
                fault = actual['P1_FAULT']
                ensure(fault['valid'] == 'true' and int(fault['kind']) == new_fault,
                       'Expected injected fault not preserved')
                ensure(fault['source'] == INJECTION, 'Fault source mismatch')
                if new_fault == 1:
                    ensure(fault['detail'] == '173' and int(fault['file_hash'], 16) != 0,
                           'Unexpected panic location')
                else:
                    ensure(fault['detail'] == '1', 'HardFault frame unavailable')
            else:
                ensure(actual == result['before']['fault']['fields'], 'Fault record changed across recovery')
        result['outcome'] = 'pass'
    except BaseException as error:
        result['outcome'] = 'failed'
        result['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        if session:
            session.close()
        result['finished_utc'] = utc()
        (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({'step': name, 'outcome': result['outcome'], 'error': result.get('error'),
                          'crc': result.get('crc'), 'fault': result.get('after', {}).get('fault'),
                          'evidence': str(out)}, indent=2), flush=True)


if __name__ == '__main__':
    main()
