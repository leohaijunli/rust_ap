#!/usr/bin/env python3
"""Install one already-built P3a image through the preserved PX4 bootloader."""

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/dev/rust_ap')
RECOVERY = ROOT / 'target/p1-hil-20261031-104403/recovery'
sys.path.insert(0, str(RECOVERY))
from run_step import Session, ensure, utc, wait_mode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image-dir', type=Path, required=True)
    parser.add_argument('--before-source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    image = args.image_dir.resolve() / 'v6x-rust-led.px4'
    report = json.loads((args.image_dir / 'v6x-rust-led.build.json').read_text())
    checksum = report['artifacts'][image.name]['sha256']
    ensure(hashlib.sha256(image.read_bytes()).hexdigest() == checksum, 'Image hash mismatch')
    ensure(report['features'] == [], 'Expected normal firmware')
    uploader = RECOVERY / 'px4_uploader.py'
    ensure(hashlib.sha256(uploader.read_bytes()).hexdigest()
           == 'f05929e1035e693005677e088e4e7085503b2e8ab3d7c8785f7bd84cd48880f8', 'Uploader hash mismatch')
    ensure(subprocess.run(['pgrep', '-x', 'QGroundControl'], capture_output=True).returncode == 1,
           'QGroundControl is using USB')
    args.output.mkdir(parents=True, exist_ok=False)
    result = {'schema': 1, 'started_utc': utc(), 'outcome': 'incomplete', 'stage': 'prepare',
              'image': str(image), 'image_sha256': checksum, 'source': report['source_id'],
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'scans': []}

    def save():
        with (args.output / 'result.json').open('w') as output:
            json.dump(result, output, indent=2)
            output.write('\n')
            output.flush()
            os.fsync(output.fileno())

    session = None
    try:
        device = wait_mode('mavlink', result['scans'])
        ensure(subprocess.run(['fuser', device], capture_output=True).returncode == 1, 'Serial port in use')
        session = Session(device, args.output / 'before-wire.jsonl')
        result['before'] = session.snapshot(args.before_source)
        result['stage'] = 'reboot-request'
        save()
        result['trigger'] = session.trigger('mavlink-reboot')
        session.close()
        session = None
        result['stage'] = 'wait-bootloader'
        save()
        wait_mode('bootloader', result['scans'])
        result['stage'] = 'upload'
        arguments = [sys.executable, '-u', str(uploader), '--port', '/dev/serial/by-id/*PX4_BL*',
                     '--debug', '--noninteractive-json', str(image)]
        result['uploader_command'] = arguments
        save()
        with (args.output / 'upload.log').open('x') as log:
            completed = subprocess.run(arguments, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=90)
        result['uploader_returncode'] = completed.returncode
        ensure(completed.returncode == 0, 'Uploader failed')
        text = (args.output / 'upload.log').read_text()
        expected = re.findall(r'Expected CRC: 0x([0-9A-Fa-f]+)', text)
        reported = re.findall(r'Reported CRC: 0x([0-9A-Fa-f]+)', text)
        result['crc'] = {'expected': expected, 'reported': reported}
        ensure(len(expected) == len(reported) == 1 and expected == reported, 'CRC mismatch')
        result['stage'] = 'verify-application'
        save()
        device = wait_mode('mavlink', result['scans'])
        session = Session(device, args.output / 'after-wire.jsonl')
        result['after'] = session.snapshot(report['source_id'])
        ensure(result['after']['fault']['fields']['P1_FAULT']['valid'] == 'false', 'Unexpected retained fault')
        ensure(result['trigger']['ack_received'], 'Reboot ACK not observed')
        result.update(outcome='pass', stage='complete')
    except BaseException as error:
        result.update(outcome='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        if session:
            session.close()
        result['finished_utc'] = utc()
        save()
        print(json.dumps({k: result.get(k) for k in ('outcome', 'stage', 'source', 'crc', 'error')}, indent=2))


if __name__ == '__main__':
    main()
