#!/usr/bin/env python3
"""Launch the verified QGC and record passive USB enumeration for this run."""

import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import serial.tools.list_ports

OUT = Path(__file__).resolve().parent
RECOVERY = OUT.parent
APP = Path('/home/dev/Applications/QGroundControl/5.1.5/QGroundControl-x86_64.AppImage')
EXPECTED = {
    APP: '9a47e4cf269d9e4f897f582f6b19aa7ebf1e9e67c9d68a532a45b541354bc344',
    RECOVERY / 'images/px4-v1.17.0-github.px4': '8f2c42787163b71e00758205ab0bed9df1669fd26d7a9f42d6f995cbabba0d7f',
    RECOVERY / 'images/normal.px4': '7652fa90836be3182becf8f888a052aebc982ecbf67e6ba303dc66719db8fff5',
    RECOVERY / 'images/p0.px4': 'd74b3b80e7c35bf4354ea568c09631f2fad362570caff414516ee0fe48a3c02d',
}


def utc():
    return datetime.now(timezone.utc).isoformat()


def dump_new(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def scan():
    return sorted([
        {'device': port.device, 'vid': port.vid, 'pid': port.pid,
         'product': port.product, 'manufacturer': port.manufacturer,
         'serial': port.serial_number, 'location': port.location,
         'read_write_access': os.access(port.device, os.R_OK | os.W_OK)}
        for port in serial.tools.list_ports.comports() if port.vid is not None
    ], key=lambda port: port['device'])


def main():
    global OUT
    platform_args = []
    environment = os.environ.copy()
    if sys.argv[1:] == ['--wayland-retry']:
        OUT = OUT / 'wayland-retry'
        OUT.mkdir(exist_ok=False)
        platform_args = ['-platform', 'wayland']
    elif sys.argv[1:] == ['--wayland-environment']:
        OUT = OUT / 'wayland-environment'
        OUT.mkdir(exist_ok=False)
        # AppRun overrides QT_QPA_PLATFORM when XDG_SESSION_TYPE=wayland.
        # Omit that variable only for this process and select native Wayland.
        environment.pop('XDG_SESSION_TYPE', None)
        environment['QT_QPA_PLATFORM'] = 'wayland'
    elif sys.argv[1:]:
        raise RuntimeError('Unsupported recorded startup attempt')
    if subprocess.run(['pgrep', '-x', 'QGroundControl'], capture_output=True).returncode != 1:
        raise RuntimeError('QGroundControl is already running')
    artifacts = []
    for path, expected in EXPECTED.items():
        with path.open('rb') as stream:
            actual = hashlib.file_digest(stream, 'sha256').hexdigest()
        if actual != expected:
            raise RuntimeError(f'Hash mismatch: {path}')
        artifacts.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': actual})
    initial = scan()
    rust = [port for port in initial if (port['vid'], port['pid']) == (0x1209, 1)]
    if len(rust) != 1 or not rust[0]['read_write_access']:
        raise RuntimeError('Expected one accessible ordinary Rust CDC')
    if subprocess.run(['fuser', rust[0]['device']], capture_output=True).returncode != 1:
        raise RuntimeError('Serial port is already held')
    official = json.loads((RECOVERY / 'images/px4-v1.17.0-github.px4').read_text())
    if official.get('board_id') != 53:
        raise RuntimeError('Unexpected official firmware board ID')
    argv = [str(APP), *platform_args, '--log-output',
            '--logging=Vehicle.VehicleSetup,VehicleSetup.FirmwareUpgrade']
    dump_new(OUT / 'launch.json', {
        'schema': 1, 'started_utc': utc(), 'argv': argv,
        'cwd': '/home/dev/rust_ap',
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'artifacts': artifacts, 'initial_ports': initial,
        'environment': {key: os.environ.get(key) for key in (
            'DISPLAY', 'WAYLAND_DISPLAY', 'XDG_SESSION_TYPE', 'XDG_RUNTIME_DIR',
            'QT_QPA_PLATFORM', 'QT_LOGGING_RULES', 'TMPDIR')},
        'child_environment': {key: environment.get(key) for key in (
            'DISPLAY', 'WAYLAND_DISPLAY', 'XDG_SESSION_TYPE', 'XDG_RUNTIME_DIR',
            'QT_QPA_PLATFORM', 'QT_LOGGING_RULES', 'TMPDIR')},
        'official_url': 'https://github.com/PX4/PX4-Autopilot/releases/download/v1.17.0/px4_fmu-v6x_default.px4',
        'monitor_scope': 'Passive USB enumeration only; this script never opens a serial port or sends a reboot.',
        'ui_scope': 'Console log is supplementary; QGC UI status requires screenshots or a complete copied log.',
    })
    with (OUT / 'qgc-console.log').open('x', buffering=1) as log, \
            (OUT / 'usb-enumeration.jsonl').open('x', buffering=1) as usb:
        process = subprocess.Popen(argv, cwd='/home/dev/rust_ap', stdout=log,
                                   stderr=subprocess.STDOUT, env=environment)
        dump_new(OUT / 'process.json', {'qgc_pid': process.pid,
                 'monitor_pid': os.getpid(), 'started_utc': utc()})
        print(f'QGC PID={process.pid}; evidence={OUT}', flush=True)
        previous = None
        while True:
            ports = scan()
            if ports != previous:
                usb.write(json.dumps({'at_utc': utc(), 'host_ns': time.monotonic_ns(),
                                      'ports': ports}) + '\n')
                previous = ports
            result = process.poll()
            if result is not None:
                break
            time.sleep(0.05)
        dump_new(OUT / 'exit.json', {'finished_utc': utc(), 'returncode': result})
        print(f'QGC exited: {result}', flush=True)
        return result


if __name__ == '__main__':
    sys.exit(main())
