#!/usr/bin/env python3
"""One direct PX4-to-normal return using the saved image and existing helpers."""

import hashlib
import json
import subprocess
from pathlib import Path

import qgc_return as common


def main():
    recovery = common.recovery
    image = common.BASE / 'images/normal.px4'
    recovery.ensure(hashlib.sha256(image.read_bytes()).hexdigest() == common.HASHES['normal.px4'],
                    'Normal image changed')
    recovery.ensure(hashlib.sha256((common.BASE / 'px4_uploader.py').read_bytes()).hexdigest()
                    == 'f05929e1035e693005677e088e4e7085503b2e8ab3d7c8785f7bd84cd48880f8', 'Uploader changed')
    recovery.ensure(subprocess.run(['pgrep', '-x', 'QGroundControl'], capture_output=True).returncode == 1,
                    'Close QGroundControl before serial operations')
    recovery.ensure(json.loads((common.BASE / '13-px4-running/result.json').read_text())['outcome'] == 'pass',
                    'PX4 running evidence is missing')
    out = common.BASE / '14-px4-to-normal-final'
    out.mkdir(exist_ok=False)
    result = {'schema': 1, 'step': out.name, 'started_utc': common.utc(), 'outcome': 'incomplete',
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'scans': []}
    session = None
    try:
        session = common.open_session('px4', result, out / 'before-wire.jsonl')
        result['before_heartbeat'] = common.wait_heartbeat(session, common.mav2.MAV_AUTOPILOT_PX4)
        result['trigger'] = session.trigger('mavlink-reboot')
        common.close_session(session)
        session = None
        recovery.wait_mode('bootloader', result['scans'])
        common.upload(out, result, 'normal.px4')
        session = common.open_session('mavlink', result, out / 'after-wire.jsonl')
        common.wait_heartbeat(session, common.mav2.MAV_AUTOPILOT_GENERIC)
        result['after'] = session.snapshot(recovery.NORMAL)
        recovery.ensure(result['after']['fault']['fields']['P1_FAULT']['valid'] == 'false',
                        'A retained fault remains')
        result['outcome'] = 'pass'
    except BaseException as error:
        result['outcome'] = 'failed'
        result['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        common.close_session(session)
        result['finished_utc'] = common.utc()
        common.save(out / 'result.json', result)
        print(json.dumps({'outcome': result['outcome'], 'error': result.get('error'),
                          'crc': result.get('upload', {}).get('crc'), 'evidence': str(out)}, indent=2))


if __name__ == '__main__':
    main()
